@if($m->misa=='1')
<span class='text-muted'>Ya Kwanza</span>

@elseif ($m->misa=='2')
<span class='text-muted'>Ya Pili</span> 

@elseif ($m->misa=='3')
<span class='text-muted'>Ya tatu</span> 

@elseif ($m->misa=='4')
<span class='text-muted'>Ya nne</span> 

@elseif ($m->misa=='5')
<span class='text-muted'>Ya tano</span> 

@endif