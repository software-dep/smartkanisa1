<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-users"></i>Church Members </h1>
            <p>welcome <?php echo e(Auth::user()->fname); ?> &nbsp; <?php echo e(Auth::user()->lname); ?></p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
            <li class="breadcrumb-item">Church Members</li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/Member')); ?>">Add Church Member</a></li>
        </ul>
    </div>
    <div class="row">

        <div class="col-md-1"></div>
        <div class="col-md-10">
            <member-component></member-component>
            


     
                  
                


                        


                
 

 



 



            

        </div>

        <div class="col-md-1"></div>



    </div>

 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>