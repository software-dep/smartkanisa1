<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-edit"></i>Contacts </h1>
        <p>welcome <?php echo e(Auth::user()->fname); ?> &nbsp; <?php echo e(Auth::user()->lname); ?></p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
        <li class="breadcrumb-item">Church Tree</li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
    </ul>
</div>
<contact-component></f-component>


<div class="col-md-2"></div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>