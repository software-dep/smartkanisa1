<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-home"></i> Home</h1>
            <p>welcome <?php echo e(Auth::user()->fname); ?> &nbsp; <?php echo e(Auth::user()->lname); ?></p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="">Home</a></li>
        </ul>
    </div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isParoko')): ?>

<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">people</i>
                </div>
                <p class="card-category">Members</p>
                <h3 class="card-title"><?php echo e($count_member); ?>

                   
                </h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons text-danger">expand_more</i>
                    <a href="<?php echo e(Route('Member.create')); ?>"> More </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">store</i>
                </div>
                <p class="card-category">Families</p>
            <h3 class="card-title"><?php echo e($count_family); ?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons">expand_more</i>
                    <a href="<?php echo e(route('Family.index')); ?>">More</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">explore</i>
                </div>
                <p class="card-category">Jumuiya</p>
                <h3 class="card-title"><?php echo e($count_jumuiya); ?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons">expand_more</i> 
                    <a href="<?php echo e(route('Jumuiya.index')); ?>">More</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
                <div class="card-icon">
                    <i class="material-icons">view_module</i>
                </div>
                <p class="card-category">Mitaa</p>
                <h3 class="card-title"><?php echo e($count_mtaa); ?></h3>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <i class="material-icons">expand_more</i> 
                    <a href="<?php echo e(route('Mitaa.index')); ?>">More</a>
                </div>
            </div>
        </div>
    </div>
</div>
 
<?php endif; ?>


<div class="row">
    <div class="col-md-6">
 <div class="card">
    <div class="card-header card-header-success">
        <h4 class="card-title">VIGANGO </h4>
        <p class="card-category">List of outstations  </p>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-hover">
            <thead class="text-success">
              
                <th>Name</th>
                
            </thead>
            <tbody>
                <?php $__currentLoopData = $vigango; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$kigango): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
             
                <td class="text-capitalize"><?php echo e($kigango->name); ?></td>
                    
                   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
        </table>
    </div>
</div>
    </div>

    <div class="col-md-6">
 <div class="card">
    <div class="card-header card-header-danger">
        <h4 class="card-title">MICHANGO </h4>
        <p class="card-category">List of recent donations </p>
    </div>
    <div class="card-body table-responsive">
        <?php if(!$michango->isEmpty()): ?>

          <table class="table table-hover">
            <thead class="text-danger">
                <th>No</th>
                <th>Name</th>
                <th>Target</th>
                <th>Amount</th>
                
            </thead>
            <tbody>
                <?php $__currentLoopData = $michango; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($key+1); ?></td>
                <td class="text-capitalize"><?php echo e($don->name); ?></td>
                <td><?php echo e($don->donation_type); ?></td>
                <td><?php echo e($don->amount); ?></td>
                    
        
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

      <?php else: ?> 
        <div class="alert alert-info">
            <h6>There is no any Donation at this time</h6>
        </div>
        <?php endif; ?>
     
    </div>
</div>
    </div>

</div>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>