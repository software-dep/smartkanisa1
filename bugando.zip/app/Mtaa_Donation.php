<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mtaa_Donation extends Model
{
    //
}
