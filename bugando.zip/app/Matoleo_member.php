<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Matoleo_member extends Model
{
    //
}
