<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kigango extends Model
{
    public function  parokia(){
        return $this->belongsTo('App\Parokia','parokis_id');
    }


    public function mtaa(){
        return $this->hasMany('App\Mtaa','kigango_id');
    }

    public function donations()
    {
        return  $this->belongsToMany('App\Donation','donation_kigango','kigango_id','donation_id')->withPivot('amount');
    }
}
