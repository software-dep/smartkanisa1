<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member_Donation extends Model
{
    //
}
