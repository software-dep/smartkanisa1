<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Familia_Donation extends Model
{
    //
}
